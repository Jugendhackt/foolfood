﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class seachFood : MonoBehaviour {
	InputField inputField;

	// Use this for initialization
	void Start () {
		inputField = GetComponent<InputField> ();
		InitInputField ();
	}
	
	// Update is called once per frame
	void Update () {
		//When man push EnterKey, App inputs the text
		if (Input.GetKey (KeyCode.Return)) {
			InputLogger ();
		}
	}

	//input text
	public void InputLogger(){
		string inputValue = inputField.text;
		Debug.Log (inputValue);
		InitInputField ();
	}

	//initialize inputField
	void InitInputField(){
		//reset value
		inputField.text = "";
		//focus
		inputField.ActivateInputField ();
	}
}

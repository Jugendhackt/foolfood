﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System;

public class showNatto : MonoBehaviour {

	private string[] outputFileName = new string[2];
	private string[] path = new string[2];
	private string[] txt = new string[2];
	public Text[] myText = new Text[2];
	TextReader txtReader;
	string txtBuffer = "";


	[SerializeField]
	RectTransform prefab = null;

	// Use this for initialization
	void Start () {
		LoadText ();
	}

	IEnumerator LoadText(){
		for(int i=0;i<2;i++){
		outputFileName[i] = "Natto_review" + (1+i).ToString() + ".txt";
		#if UNITY_EDITOR
			path[i] = Application.dataPath +"/StreamingAssets/"+ outputFileName[i];
			FileStream file = new FileStream(path[i],FileMode.Open,FileAccess.Read);
			txtReader = new StreamReader(file);
			yield return new WaitForSeconds(0f);
		#elif UNITY_ANDROID
			path = "jar:file://" + Application.dataPath + "!/assets" + "/" + textFileName;
			WWW www = new WWW(path);
			yield return www;
			txtReader = new StringReader(www.text);
		#endif	
			txt [i] = "";
			Debug.Log (path[i]);
			
			//for read file
			while((txtBuffer = txtReader.ReadLine())!=null){
				txt[i] = txt[i] + txtBuffer + "\r\n";
			}

			Debug.Log (txt[i]);

			myText[i] = GetComponentInChildren<Text>();
			myText[i].text = "a";

			var item = GameObject.Instantiate(prefab) as RectTransform;
			item.SetParent(transform, false);
			var text = item.GetComponentInChildren<Text>();
			text.text = txt[i];

		}

	}
	
	// Update is called once per frame
	void Update () {
		for (int i = 0; i < 2; i++) {
			myText[i].text = txt[i];
		}
	}
}

﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System;

public class ScrollController : MonoBehaviour {

	[SerializeField]
	RectTransform prefab = null;
	private string dataPath = "";
	private string guitxt = "";
	private string outputFileName = "FoodData" + "/" + "allName.txt";

	public string[] foodName;

	void Start ()
	{


		//show data's path
		string txt = Application.dataPath;
		dataPath = txt +"/"+ outputFileName;
		Debug.Log (dataPath);

		//for read file
		FileInfo fi = new FileInfo (dataPath);
		try {
			using (StreamReader sr = new StreamReader (fi.OpenRead (), Encoding.UTF8)) {
				guitxt = sr.ReadToEnd ();
			}
		} catch (Exception e) {
			var item = GameObject.Instantiate(prefab) as RectTransform;
			item.SetParent(transform, false);
			var text = item.GetComponentInChildren<Text>();
			text.text =  ":" + guitxt;
		}
	}


}